

Sgraficar <- function(input){
  
}
